﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using OnlineCakeStore.CommonFolder;
using OnlineCakeStore.Helpers;
using OnlineCakeStore.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineCakeStore.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly admin_ProjectContext _db;

        public HomeController(ILogger<HomeController> logger, admin_ProjectContext db)
        {
            _logger = logger;
            _db = db;
        }

        public IActionResult Index(string vegid, string size)
        {

            TempData.Keep("cakewithsizeinstoredp");
            ViewBag.SelectedRadioVeg = false;
            ViewBag.SelectedRadioNonVeg = false;

            Commonclass ces = new Commonclass();


            if (vegid == null & size == null)
            {

                ces.listofcake = _db.CakTableCakes.ToList();


            }

            else
            {

                if (vegid == "N")
                {
                    ViewBag.SelectedRadioNonVeg = true;
                }

                else
                {
                    ViewBag.SelectedRadioVeg = true;
                }
                ces.restrauts = _db.Sizefromstoredps.FromSqlRaw<Sizefromstoredp>("EXEC Getcakewithsize {0}", vegid).ToList();

                ces.listofcake = _db.CakTableCakes.Where(p => p.Cakvegnonveg == vegid).ToList();
                ces.cakesize = _db.CakTableSizes.ToList();

                if (size != null & vegid != null)
                {

                    ViewBag.sizeis = 1;
                    ces.cakewithsizeinstoredplist = _db.cakewithsizeinstoredps.FromSqlRaw<cakewithsizeinstoredp>("EXEC CAKEWITHSIZEOFCAKE {0},{1}", size, vegid).ToList();

                }

            }

            return View(ces);
        }


        public IActionResult Order(int orderid, CakTableOrd cakTableOrd, string sizwgt, int sizeid)
        {
            
            Commonclass ces = new Commonclass();
            var productlist = TempDataHelper.Get<List<cakewithsizeinstoredp>>(TempData, "cakewithsizeinstoredp") as List<cakewithsizeinstoredp>;
            if(productlist==null)
            {

                productlist = new List<cakewithsizeinstoredp>();
            }


            List<CakTableOrd> GetorderandcakemodelLIST = new List<CakTableOrd>();
            GetorderandcakemodelLIST = ces.Getorderandcakelist = _db.CakTableOrds.ToList();
            if (sizeid != 0)
            {

                CakTableOrd ord = new CakTableOrd();


                foreach (var li in productlist)
                {

                    var result = _db.CakTableOrds.FirstOrDefault(p => p.Ordsizecod == li.Sizecod);
                    var result1 = _db.CakTableSizes.FirstOrDefault(p => p.Sizecod == li.Sizecod);
                    if (result == null)
                    {

                         _db.Add(ord);
                        ord.Orddate = DateTime.Now;
                        ord.Ordphoneno = cakTableOrd.Ordphoneno;
                        ord.Ordqty = cakTableOrd.Ordqty;
                        ord.Ordsizecod = li.Sizecod;
                        _db.SaveChanges();
                        
                    }

                   else
                    {
 
                        result.Ordqty = cakTableOrd.Ordqty;
                        result.Ordphoneno = cakTableOrd.Ordphoneno;
                        result1.Sizeqtyleft -= result.Ordqty;
                        _db.SaveChanges();
                   }

                }

             
            }
            var listRecords = ces.cakewithsizeinstoredplist = _db.cakewithsizeinstoredps.FromSqlRaw<cakewithsizeinstoredp>("EXEC Getcakeoncakecode {0},{1}", sizwgt, orderid).ToList();

            productlist.AddRange(listRecords);

            TempDataHelper.Put<List<cakewithsizeinstoredp>>(TempData, "cakewithsizeinstoredp", productlist);

            //List<cakewithsizeinstoredp> cakewithsizeinstoredp = (List<cakewithsizeinstoredp>)TempData["cakewithsizeinstoredp"];
            TempData.Keep("cakewithsizeinstoredp");

            //foreach (var cakewithid in ces. cakewithsizeinstoredplist)
            //{
            //    TempData["sizcode"] = cakewithid.Sizecod;
            //    TempData["cakename"] = cakewithid.Cakename;
            //    TempData["cakeimage"] = cakewithid.Cakimg;
            //    TempData["cakeprice"] = cakewithid.Sizeprice;
            //    TempData["sizeleft"] = cakewithid.Sizeqtyleft;
            //    TempData["sizewgt"] = cakewithid.Sizewgt;

            //    TempDataHelper.Put<cakewithsizeinstoredp>(TempData, "cakewithsizeinstoredp", cakewithid);


            //}
            //var productlist = TempDataHelper.Get<List<cakewithsizeinstoredp>>(TempData, "cakewithsizeinstoredp") as List<cakewithsizeinstoredp>;
            return View(ces);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}






