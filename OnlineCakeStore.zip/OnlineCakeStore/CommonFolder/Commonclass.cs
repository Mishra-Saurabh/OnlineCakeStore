﻿using OnlineCakeStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineCakeStore.CommonFolder
{
    public class Commonclass
    {



        public List<CakTableCake> totallistcake = new List<CakTableCake>();
        public List<CakTableCake> listofcake = new List<CakTableCake>();
        public List<CakTableSize> cakesize = new List<CakTableSize>();
        public List<Sizefromstoredp> restrauts = new List<Sizefromstoredp>();
        public List<cakewithsizeinstoredp> cakewithsizeinstoredplist = new List<cakewithsizeinstoredp>();
        public List<CakTableOrd> Getorderandcakelist = new List<CakTableOrd>();
        public List<cakewithsizeinstoredp> listRecordslistfortempdata = new List<cakewithsizeinstoredp>();

        public CakTableOrd cakTableOrd { get; set; }



    }
}
