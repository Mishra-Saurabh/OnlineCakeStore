﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class CakTableOrd
    {
        public int Ordcod { get; set; }
        public DateTime? Orddate { get; set; }
        public int? Ordsizecod { get; set; }
        public string Ordphoneno { get; set; }
        public int? Ordqty { get; set; }

        public virtual CakTableSize OrdsizecodNavigation { get; set; }
    }
}
