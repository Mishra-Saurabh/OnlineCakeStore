﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class TbSubcat
    {
        public TbSubcat()
        {
            TbPrds = new HashSet<TbPrd>();
        }

        public int Subcatcod { get; set; }
        public string Subcatname { get; set; }
        public int? SubcatCatcod { get; set; }

        public virtual TbCat SubcatCatcodNavigation { get; set; }
        public virtual ICollection<TbPrd> TbPrds { get; set; }
    }
}
