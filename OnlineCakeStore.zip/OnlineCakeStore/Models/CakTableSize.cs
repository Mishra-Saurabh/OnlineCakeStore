﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class CakTableSize
    {
        public CakTableSize()
        {
            CakTableOrds = new HashSet<CakTableOrd>();
        }

        public int Sizecod { get; set; }
        public int? SizeCakcod { get; set; }
        public string Sizewgt { get; set; }
        public int? Sizeprice { get; set; }
        public int? Sizeqtyleft { get; set; }

        public virtual CakTableCake SizeCakcodNavigation { get; set; }
        public virtual ICollection<CakTableOrd> CakTableOrds { get; set; }
    }
}
