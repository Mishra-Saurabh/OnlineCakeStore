﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class ResTableMnuitem
    {
        public int MnuitemCod { get; set; }
        public string MnuitemName { get; set; }
        public string MnuitemDsc { get; set; }
        public double? MnuitemPrice { get; set; }
        public int? MnuitemRescod { get; set; }
        public string MnuitemPic { get; set; }

        public virtual ResTableRe MnuitemRescodNavigation { get; set; }
    }
}
