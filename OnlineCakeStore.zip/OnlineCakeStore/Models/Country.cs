﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class Country
    {
        public Country()
        {
            SiteUsers = new HashSet<SiteUser>();
            States = new HashSet<State>();
        }

        public int CountryId { get; set; }
        public string CountryName { get; set; }

        public virtual ICollection<SiteUser> SiteUsers { get; set; }
        public virtual ICollection<State> States { get; set; }
    }
}
