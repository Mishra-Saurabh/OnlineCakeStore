﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineCakeStore.Models
{
    public class cakewithsizeinstoredp
    {

        [Key]
        public int Cakcod { get; set; }
        public int Sizecod { get; set; }
      
        public string Cakename { get; set; }

        public string Cakvegnonveg { get; set; }
        public string Cakimg { get; set; }

        public int? size_cakcod { get; set; }
        public string Sizewgt { get; set; }

        public int? Sizeqtyleft { get; set; }
        public int? Sizeprice { get; set; }





    }
}
