﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class SiteUser
    {
        public SiteUser()
        {
            Addresses = new HashSet<Address>();
        }

        public int Userid { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Phoneno { get; set; }
        public string Image { get; set; }
        public string Designation { get; set; }
        public int? Gender { get; set; }
        public DateTime? Dob { get; set; }
        public int? Roleid { get; set; }
        public DateTime? Dateforresetpassword { get; set; }
        public string ResetPasswordCode { get; set; }
        public bool? IsaCtive { get; set; }
        public int? CountryId { get; set; }
        public int? StateId { get; set; }
        public int? CityId { get; set; }

        public virtual City City { get; set; }
        public virtual Country Country { get; set; }
        public virtual RoleTable Role { get; set; }
        public virtual State State { get; set; }
        public virtual ICollection<Address> Addresses { get; set; }
    }
}
