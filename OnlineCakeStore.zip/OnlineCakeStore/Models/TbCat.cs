﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class TbCat
    {
        public TbCat()
        {
            TbSubcats = new HashSet<TbSubcat>();
        }

        public int Catcod { get; set; }
        public string Catname { get; set; }

        public virtual ICollection<TbSubcat> TbSubcats { get; set; }
    }
}
