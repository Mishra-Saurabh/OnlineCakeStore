﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class Address
    {
        public int AdressId { get; set; }
        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public int? UserId { get; set; }
        public bool? IspermanentId { get; set; }

        public virtual SiteUser User { get; set; }
    }
}
