﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class PermissionTable
    {
        public PermissionTable()
        {
            Table1s = new HashSet<Table1>();
        }

        public int Permissionid { get; set; }
        public string Permissionname { get; set; }

        public virtual ICollection<Table1> Table1s { get; set; }
    }
}
