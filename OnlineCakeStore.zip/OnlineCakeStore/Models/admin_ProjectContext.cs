﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class admin_ProjectContext : DbContext
    {
        public admin_ProjectContext()
        {
        }

        public admin_ProjectContext(DbContextOptions<admin_ProjectContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Address> Addresses { get; set; }
        public virtual DbSet<CakTableCake> CakTableCakes { get; set; }
        public virtual DbSet<CakTableOrd> CakTableOrds { get; set; }
        public virtual DbSet<CakTableSize> CakTableSizes { get; set; }
        public virtual DbSet<City> Cities { get; set; }
        public virtual DbSet<Country> Countries { get; set; }
        public virtual DbSet<PermissionTable> PermissionTables { get; set; }
        public virtual DbSet<ResTableCity> ResTableCities { get; set; }
        public virtual DbSet<ResTableMnuitem> ResTableMnuitems { get; set; }
        public virtual DbSet<ResTableRe> ResTableRes { get; set; }
        public virtual DbSet<RoleTable> RoleTables { get; set; }
        public virtual DbSet<SiteUser> SiteUsers { get; set; }
        public virtual DbSet<State> States { get; set; }
        public virtual DbSet<Table1> Table1s { get; set; }
        public virtual DbSet<TbCat> TbCats { get; set; }
        public virtual DbSet<TbPrd> TbPrds { get; set; }
        public virtual DbSet<TbReg> TbRegs { get; set; }
        public virtual DbSet<TbSubcat> TbSubcats { get; set; }
        public virtual DbSet<TbWshlst> TbWshlsts { get; set; }
        public virtual DbSet<Sizefromstoredp> Sizefromstoredps { get; set; }
        public virtual DbSet<Getorderandcakemodel> Getorderandcakemodels { get; set; }

        public virtual DbSet<cakewithsizeinstoredp> cakewithsizeinstoredps { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=quaydb,1434;Initial Catalog=admin_Project;User ID=sql2019;Password=Spm345$");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Address>(entity =>
            {
                entity.HasKey(e => e.AdressId)
                    .HasName("PK_adress");

                entity.ToTable("address");

                entity.Property(e => e.City)
                    .HasMaxLength(100)
                    .HasColumnName("city")
                    .IsFixedLength(true);

                entity.Property(e => e.IspermanentId).HasColumnName("ispermanentId");

                entity.Property(e => e.Line1)
                    .HasMaxLength(500)
                    .HasColumnName("line1");

                entity.Property(e => e.Line2)
                    .HasMaxLength(1000)
                    .HasColumnName("line2")
                    .IsFixedLength(true);

                entity.Property(e => e.PostalCode)
                    .HasMaxLength(100)
                    .HasColumnName("postalCode")
                    .IsFixedLength(true);

                entity.Property(e => e.UserId).HasColumnName("userId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Addresses)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK_adress_SiteUser");
            });

            modelBuilder.Entity<CakTableCake>(entity =>
            {
                entity.HasKey(e => e.Cakcod);

                entity.ToTable("cak_table_cake");

                entity.Property(e => e.Cakcod).HasColumnName("cakcod");

                entity.Property(e => e.Cakdesc)
                    .HasMaxLength(1000)
                    .HasColumnName("cakdesc")
                    .IsFixedLength(true);

                entity.Property(e => e.Cakename)
                    .HasMaxLength(100)
                    .HasColumnName("cakename")
                    .IsFixedLength(true);

                entity.Property(e => e.Cakimg)
                    .HasMaxLength(100)
                    .HasColumnName("cakimg")
                    .IsFixedLength(true);

                entity.Property(e => e.Cakvegnonveg)
                    .HasMaxLength(1)
                    .HasColumnName("cakvegnonveg")
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<CakTableOrd>(entity =>
            {
                entity.HasKey(e => e.Ordcod);

                entity.ToTable("cak_table_ord");

                entity.Property(e => e.Ordcod).HasColumnName("ordcod");

                entity.Property(e => e.Orddate)
                    .HasColumnType("datetime")
                    .HasColumnName("orddate");

                entity.Property(e => e.Ordphoneno)
                    .HasMaxLength(15)
                    .HasColumnName("ordphoneno")
                    .IsFixedLength(true);

                entity.Property(e => e.Ordqty).HasColumnName("ordqty");

                entity.Property(e => e.Ordsizecod).HasColumnName("ordsizecod");

                entity.HasOne(d => d.OrdsizecodNavigation)
                    .WithMany(p => p.CakTableOrds)
                    .HasForeignKey(d => d.Ordsizecod)
                    .HasConstraintName("FK_cak_table_ord_cak_table_size");
            });

            modelBuilder.Entity<CakTableSize>(entity =>
            {
                entity.HasKey(e => e.Sizecod);

                entity.ToTable("cak_table_size");

                entity.Property(e => e.Sizecod).HasColumnName("sizecod");

                entity.Property(e => e.SizeCakcod).HasColumnName("size_cakcod");

                entity.Property(e => e.Sizeprice).HasColumnName("sizeprice");

                entity.Property(e => e.Sizeqtyleft).HasColumnName("sizeqtyleft");

                entity.Property(e => e.Sizewgt)
                    .HasMaxLength(100)
                    .HasColumnName("sizewgt")
                    .IsFixedLength(true);

                entity.HasOne(d => d.SizeCakcodNavigation)
                    .WithMany(p => p.CakTableSizes)
                    .HasForeignKey(d => d.SizeCakcod)
                    .HasConstraintName("FK_cak_table_size_cak_table_cake");
            });

            modelBuilder.Entity<City>(entity =>
            {
                entity.ToTable("City");

                entity.Property(e => e.CityName).HasMaxLength(200);

                entity.HasOne(d => d.State)
                    .WithMany(p => p.Cities)
                    .HasForeignKey(d => d.StateId)
                    .HasConstraintName("FK_City_State");
            });

            modelBuilder.Entity<Country>(entity =>
            {
                entity.ToTable("Country");

                entity.Property(e => e.CountryId).HasColumnName("CountryID");

                entity.Property(e => e.CountryName)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PermissionTable>(entity =>
            {
                entity.HasKey(e => e.Permissionid);

                entity.ToTable("permission_table");

                entity.Property(e => e.Permissionid).HasColumnName("permissionid");

                entity.Property(e => e.Permissionname)
                    .HasMaxLength(100)
                    .HasColumnName("permissionname")
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<ResTableCity>(entity =>
            {
                entity.HasKey(e => e.CityCod);

                entity.ToTable("res_table_city");

                entity.Property(e => e.CityCod).HasColumnName("city_cod");

                entity.Property(e => e.CityName)
                    .HasMaxLength(100)
                    .HasColumnName("city_name")
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<ResTableMnuitem>(entity =>
            {
                entity.HasKey(e => e.MnuitemCod);

                entity.ToTable("res_table_mnuitem");

                entity.Property(e => e.MnuitemCod).HasColumnName("mnuitem_cod");

                entity.Property(e => e.MnuitemDsc)
                    .HasMaxLength(1000)
                    .HasColumnName("mnuitem_dsc")
                    .IsFixedLength(true);

                entity.Property(e => e.MnuitemName)
                    .HasMaxLength(100)
                    .HasColumnName("mnuitem_name")
                    .IsFixedLength(true);

                entity.Property(e => e.MnuitemPic)
                    .HasMaxLength(1000)
                    .HasColumnName("mnuitem_pic")
                    .IsFixedLength(true);

                entity.Property(e => e.MnuitemPrice).HasColumnName("mnuitem_price");

                entity.Property(e => e.MnuitemRescod).HasColumnName("mnuitem_rescod");

                entity.HasOne(d => d.MnuitemRescodNavigation)
                    .WithMany(p => p.ResTableMnuitems)
                    .HasForeignKey(d => d.MnuitemRescod)
                    .HasConstraintName("FK_res_table_mnuitem_res_table_res");
            });

            modelBuilder.Entity<ResTableRe>(entity =>
            {
                entity.HasKey(e => e.ResCod);

                entity.ToTable("res_table_res");

                entity.Property(e => e.ResCod).HasColumnName("res_cod");

                entity.Property(e => e.ResCitycod).HasColumnName("res_citycod");

                entity.Property(e => e.ResName)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("res_name");

                entity.Property(e => e.ResPhn)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("res_phn");

                entity.Property(e => e.ResPic)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("res_pic");

                entity.Property(e => e.ResRate).HasColumnName("res_rate");

                entity.HasOne(d => d.ResCitycodNavigation)
                    .WithMany(p => p.ResTableRes)
                    .HasForeignKey(d => d.ResCitycod)
                    .HasConstraintName("FK_res_table_res_res_table_city");
            });

            modelBuilder.Entity<RoleTable>(entity =>
            {
                entity.HasKey(e => e.Roleid);

                entity.ToTable("role_table");

                entity.Property(e => e.Roleid).HasColumnName("roleid");

                entity.Property(e => e.Rolename)
                    .HasMaxLength(100)
                    .HasColumnName("rolename")
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<SiteUser>(entity =>
            {
                entity.HasKey(e => e.Userid);

                entity.ToTable("SiteUser");

                entity.Property(e => e.Userid).HasColumnName("userid");

                entity.Property(e => e.Dateforresetpassword).HasColumnType("date");

                entity.Property(e => e.Designation)
                    .HasMaxLength(1000)
                    .HasColumnName("designation");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("DOB");

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .HasColumnName("email")
                    .IsFixedLength(true);

                entity.Property(e => e.Firstname)
                    .HasMaxLength(100)
                    .HasColumnName("firstname")
                    .IsFixedLength(true);

                entity.Property(e => e.Image)
                    .HasMaxLength(1000)
                    .HasColumnName("image")
                    .IsFixedLength(true);

                entity.Property(e => e.IsaCtive).HasColumnName("ISaCTIVE");

                entity.Property(e => e.Lastname)
                    .HasMaxLength(100)
                    .HasColumnName("lastname")
                    .IsFixedLength(true);

                entity.Property(e => e.Password)
                    .HasMaxLength(100)
                    .HasColumnName("password")
                    .IsFixedLength(true);

                entity.Property(e => e.Phoneno)
                    .HasMaxLength(115)
                    .HasColumnName("phoneno")
                    .IsFixedLength(true);

                entity.Property(e => e.Roleid).HasColumnName("roleid");

                entity.Property(e => e.Username)
                    .HasMaxLength(100)
                    .HasColumnName("username")
                    .IsFixedLength(true);

                entity.HasOne(d => d.City)
                    .WithMany(p => p.SiteUsers)
                    .HasForeignKey(d => d.CityId)
                    .HasConstraintName("FK_SiteUser_City");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.SiteUsers)
                    .HasForeignKey(d => d.CountryId)
                    .HasConstraintName("FK_SiteUser_Country");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.SiteUsers)
                    .HasForeignKey(d => d.Roleid)
                    .HasConstraintName("FK_SiteUser_role_table");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.SiteUsers)
                    .HasForeignKey(d => d.StateId)
                    .HasConstraintName("FK_SiteUser_State");
            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.ToTable("State");

                entity.Property(e => e.StateId).HasColumnName("StateID");

                entity.Property(e => e.StateName)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.States)
                    .HasForeignKey(d => d.CountryId)
                    .HasConstraintName("FK_State_Country");
            });

            modelBuilder.Entity<Table1>(entity =>
            {
                entity.HasKey(e => e.Adminuserid);

                entity.ToTable("Table_1");

                entity.Property(e => e.Adminuserid).HasColumnName("adminuserid");

                entity.Property(e => e.Permissionid).HasColumnName("permissionid");

                entity.Property(e => e.Rolefix)
                    .HasMaxLength(100)
                    .HasColumnName("rolefix")
                    .IsFixedLength(true);

                entity.Property(e => e.Roleid).HasColumnName("roleid");

                entity.HasOne(d => d.Permission)
                    .WithMany(p => p.Table1s)
                    .HasForeignKey(d => d.Permissionid)
                    .HasConstraintName("FK_Table_1_permission_table");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Table1s)
                    .HasForeignKey(d => d.Roleid)
                    .HasConstraintName("FK_Table_1_role_table");
            });

            modelBuilder.Entity<TbCat>(entity =>
            {
                entity.HasKey(e => e.Catcod);

                entity.ToTable("tb_cat");

                entity.Property(e => e.Catcod).HasColumnName("catcod");

                entity.Property(e => e.Catname).HasColumnName("catname");
            });

            modelBuilder.Entity<TbPrd>(entity =>
            {
                entity.HasKey(e => e.Prdcod);

                entity.ToTable("tb_prd");

                entity.Property(e => e.Prdcod).HasColumnName("prdcod");

                entity.Property(e => e.PrdSubcatcod).HasColumnName("prd_subcatcod");

                entity.Property(e => e.Prddisc)
                    .HasMaxLength(1000)
                    .HasColumnName("prddisc");

                entity.Property(e => e.Prdname)
                    .HasMaxLength(1000)
                    .HasColumnName("prdname");

                entity.Property(e => e.Prdpic)
                    .HasMaxLength(1000)
                    .HasColumnName("prdpic");

                entity.Property(e => e.Prdprice).HasColumnName("prdprice");

                entity.HasOne(d => d.PrdSubcatcodNavigation)
                    .WithMany(p => p.TbPrds)
                    .HasForeignKey(d => d.PrdSubcatcod)
                    .HasConstraintName("FK_tb_prd_tb_subcat");
            });

            modelBuilder.Entity<TbReg>(entity =>
            {
                entity.HasKey(e => e.Regcod);

                entity.ToTable("tb_reg");

                entity.Property(e => e.Regcod).HasColumnName("regcod");

                entity.Property(e => e.Regemail)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("regemail");

                entity.Property(e => e.Regpassword)
                    .HasMaxLength(100)
                    .HasColumnName("regpassword")
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<TbSubcat>(entity =>
            {
                entity.HasKey(e => e.Subcatcod);

                entity.ToTable("tb_subcat");

                entity.Property(e => e.Subcatcod).HasColumnName("subcatcod");

                entity.Property(e => e.SubcatCatcod).HasColumnName("subcat_catcod");

                entity.Property(e => e.Subcatname)
                    .HasMaxLength(1000)
                    .HasColumnName("subcatname")
                    .IsFixedLength(true);

                entity.HasOne(d => d.SubcatCatcodNavigation)
                    .WithMany(p => p.TbSubcats)
                    .HasForeignKey(d => d.SubcatCatcod)
                    .HasConstraintName("FK_tb_subcat_tb_cat");
            });

            modelBuilder.Entity<TbWshlst>(entity =>
            {
                entity.HasKey(e => e.Wshlst);

                entity.ToTable("tb_wshlst");

                entity.Property(e => e.Wshlst).HasColumnName("wshlst");

                entity.Property(e => e.Quantity).HasColumnName("quantity");

                entity.Property(e => e.WshlstPrdcod).HasColumnName("wshlst_prdcod");

                entity.Property(e => e.WshlstRegcod).HasColumnName("wshlst_regcod");

                entity.Property(e => e.Wshlstdate)
                    .HasColumnType("datetime")
                    .HasColumnName("wshlstdate");

                entity.HasOne(d => d.WshlstPrdcodNavigation)
                    .WithMany(p => p.TbWshlsts)
                    .HasForeignKey(d => d.WshlstPrdcod)
                    .HasConstraintName("FK_tb_wshlst_tb_prd");

                entity.HasOne(d => d.WshlstRegcodNavigation)
                    .WithMany(p => p.TbWshlsts)
                    .HasForeignKey(d => d.WshlstRegcod)
                    .HasConstraintName("FK_tb_wshlst_tb_reg");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
