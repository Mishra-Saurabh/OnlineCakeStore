﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class TbWshlst
    {
        public int Wshlst { get; set; }
        public int? WshlstRegcod { get; set; }
        public int? WshlstPrdcod { get; set; }
        public DateTime? Wshlstdate { get; set; }
        public int? Quantity { get; set; }

        public virtual TbPrd WshlstPrdcodNavigation { get; set; }
        public virtual TbReg WshlstRegcodNavigation { get; set; }
    }
}
