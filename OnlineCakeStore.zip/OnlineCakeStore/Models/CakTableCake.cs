﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class CakTableCake
    {
        public CakTableCake()
        {
            CakTableSizes = new HashSet<CakTableSize>();
        }

        public int Cakcod { get; set; }
        public string Cakename { get; set; }
        public string Cakimg { get; set; }
        public string Cakdesc { get; set; }
        public string Cakvegnonveg { get; set; }

        public virtual ICollection<CakTableSize> CakTableSizes { get; set; }
    }
}
