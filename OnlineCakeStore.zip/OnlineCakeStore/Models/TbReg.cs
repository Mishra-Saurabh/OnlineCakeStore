﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class TbReg
    {
        public TbReg()
        {
            TbWshlsts = new HashSet<TbWshlst>();
        }

        public int Regcod { get; set; }
        public string Regemail { get; set; }
        public string Regpassword { get; set; }

        public virtual ICollection<TbWshlst> TbWshlsts { get; set; }
    }
}
