﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class RoleTable
    {
        public RoleTable()
        {
            SiteUsers = new HashSet<SiteUser>();
            Table1s = new HashSet<Table1>();
        }

        public int Roleid { get; set; }
        public string Rolename { get; set; }

        public virtual ICollection<SiteUser> SiteUsers { get; set; }
        public virtual ICollection<Table1> Table1s { get; set; }
    }
}
