﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class ResTableRe
    {
        public ResTableRe()
        {
            ResTableMnuitems = new HashSet<ResTableMnuitem>();
        }

        public int ResCod { get; set; }
        public string ResName { get; set; }
        public int? ResRate { get; set; }
        public string ResPhn { get; set; }
        public int? ResCitycod { get; set; }
        public string ResPic { get; set; }

        public virtual ResTableCity ResCitycodNavigation { get; set; }
        public virtual ICollection<ResTableMnuitem> ResTableMnuitems { get; set; }
    }
}
