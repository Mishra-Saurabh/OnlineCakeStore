﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineCakeStore.Models
{
    public class Getorderandcakemodel
    {
   [Key]
   //public int ordcod { get; set; }
   public int Sizecod { get; set; }
   public string Cakename { get; set; }
   public int? Sizeprice { get; set; }
   public int? Sizeqtyleft { get; set; }
   //public string Ordphoneno { get; set; }
  public string Sizewgt { get; set; }
  public string Cakimg { get; set; }
  //public int? Ordqty { get; set; }

    }
}
