﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class TbPrd
    {
        public TbPrd()
        {
            TbWshlsts = new HashSet<TbWshlst>();
        }

        public int Prdcod { get; set; }
        public string Prdname { get; set; }
        public int? PrdSubcatcod { get; set; }
        public string Prddisc { get; set; }
        public string Prdpic { get; set; }
        public double? Prdprice { get; set; }

        public virtual TbSubcat PrdSubcatcodNavigation { get; set; }
        public virtual ICollection<TbWshlst> TbWshlsts { get; set; }
    }
}
