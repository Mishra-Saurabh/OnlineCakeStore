﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class ResTableCity
    {
        public ResTableCity()
        {
            ResTableRes = new HashSet<ResTableRe>();
        }

        public int CityCod { get; set; }
        public string CityName { get; set; }

        public virtual ICollection<ResTableRe> ResTableRes { get; set; }
    }
}
