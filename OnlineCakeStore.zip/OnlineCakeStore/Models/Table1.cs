﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OnlineCakeStore.Models
{
    public partial class Table1
    {
        public int Adminuserid { get; set; }
        public int? Roleid { get; set; }
        public int? Permissionid { get; set; }
        public string Rolefix { get; set; }

        public virtual PermissionTable Permission { get; set; }
        public virtual RoleTable Role { get; set; }
    }
}
